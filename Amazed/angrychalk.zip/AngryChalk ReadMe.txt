Information about AngryChalk

This font has been created by Jeroen Kant.
This is free for personal use.
When it's being used for commercial purposes, please first contact me at:
jeroen.kant@hetnet.nl

Jeroen Kant � 2011